package com.secret.diary

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.secret.diary.model.DiaryEntry

class EntryAdapter(val onOpen: (DiaryEntry)->Unit) : RecyclerView.Adapter<EntryAdapter.VH>() {
    private val items = mutableListOf<DiaryEntry>()
    fun setEntries(list: List<DiaryEntry>){
        items.clear()
        items.addAll(list)
        notifyDataSetChanged()
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_entry, parent, false)
        return VH(v)
    }
    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = items[position]
        holder.title.text = e.title.ifEmpty { "(no title)" }
        holder.preview.text = e.content.take(120)
        holder.itemView.setOnClickListener { onOpen(e) }
    }
    override fun getItemCount(): Int = items.size
    class VH(v: View): RecyclerView.ViewHolder(v){
        val title: TextView = v.findViewById(R.id.entry_title)
        val preview: TextView = v.findViewById(R.id.entry_preview)
    }
}
