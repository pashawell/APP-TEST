package com.secret.diary

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import com.secret.diary.model.DiaryEntry

class EditEntryActivity : AppCompatActivity() {

    private var filename: String = ""
    private lateinit var titleView: EditText
    private lateinit var contentView: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_entry)
        titleView = findViewById(R.id.edit_title)
        contentView = findViewById(R.id.edit_content)
        filename = intent.getStringExtra("filename") ?: ""

        if (filename.isNotEmpty()) {
            val e = EntryRepository.load(filename)
            if (e != null) {
                titleView.setText(e.title)
                contentView.setText(e.content)
            }
        }

        findViewById<Button>(R.id.btn_save).setOnClickListener {
            val entry = DiaryEntry(
                filename = if (filename.isEmpty()) "" else filename,
                title = titleView.text.toString(),
                content = contentView.text.toString(),
                mood = "🙂",
                timestamp = System.currentTimeMillis()
            )
            EntryRepository.save(entry)
            finish()
        }
    }
}
