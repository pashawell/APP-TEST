package com.secret.diary

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private lateinit var recycler: RecyclerView
    private lateinit var adapter: EntryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recycler = findViewById(R.id.recycler)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = EntryAdapter { entry ->
            // open edit
            val i = Intent(this, EditEntryActivity::class.java)
            i.putExtra("filename", entry.filename)
            startActivity(i)
        }
        recycler.adapter = adapter

        findViewById<FloatingActionButton>(R.id.fab_add).setOnClickListener {
            startActivity(Intent(this, EditEntryActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        // load entries
        adapter.setEntries(EntryRepository.loadAll())
    }
}
