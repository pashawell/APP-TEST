package com.secret.diary

import android.content.Context
import android.os.Build
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import com.secret.diary.model.DiaryEntry
import java.io.File
import java.nio.charset.Charset

object EntryRepository {
    private const val PREFIX = "entry_"

    private fun masterKey(context: Context): MasterKey {
        return MasterKey.Builder(context, MasterKey.DEFAULT_MASTER_KEY_ALIAS)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
    }

    fun save(entry: DiaryEntry) {
        val ctx = SecretDiaryApp.appContext()
        val filename = entry.filename.ifEmpty { PREFIX + System.currentTimeMillis().toString() + ".json" }
        val file = File(ctx.filesDir, filename)
        val mf = masterKey(ctx)
        val encryptedFile = EncryptedFile.Builder(
            ctx,
            file,
            mf,
            androidx.security.crypto.EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        encryptedFile.openFileOutput().use { it.write(entry.toJson().toByteArray(Charset.forName("UTF-8"))) }
    }

    fun loadAll(): List<DiaryEntry> {
        val ctx = SecretDiaryApp.appContext()
        val files = ctx.filesDir.listFiles() ?: arrayOf()
        val entries = mutableListOf<DiaryEntry>()
        val mf = masterKey(ctx)
        for (f in files) {
            if (!f.name.startsWith(PREFIX)) continue
            try {
                val encryptedFile = EncryptedFile.Builder(
                    ctx,
                    f,
                    mf,
                    androidx.security.crypto.EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
                ).build()
                val content = encryptedFile.openFileInput().readBytes().toString(Charset.forName("UTF-8"))
                entries.add(DiaryEntry.fromJson(f.name, content))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        // sort by timestamp desc
        entries.sortByDescending { it.timestamp }
        return entries
    }

    fun load(filename: String): DiaryEntry? {
        val ctx = SecretDiaryApp.appContext()
        val f = File(ctx.filesDir, filename)
        if (!f.exists()) return null
        val mf = masterKey(ctx)
        val encryptedFile = EncryptedFile.Builder(
            ctx,
            f,
            mf,
            androidx.security.crypto.EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB
        ).build()
        val content = encryptedFile.openFileInput().readBytes().toString(Charset.forName("UTF-8"))
        return DiaryEntry.fromJson(f.name, content)
    }
}
