package com.secret.diary.model

import org.json.JSONObject

data class DiaryEntry(
    val filename: String,
    var title: String,
    var content: String,
    var mood: String,
    var timestamp: Long
) {
    fun toJson(): String {
        val o = JSONObject()
        o.put("title", title)
        o.put("content", content)
        o.put("mood", mood)
        o.put("timestamp", timestamp)
        return o.toString()
    }
    companion object {
        fun fromJson(filename: String, json: String): DiaryEntry {
            val o = JSONObject(json)
            return DiaryEntry(
                filename = filename,
                title = o.optString("title",""),
                content = o.optString("content",""),
                mood = o.optString("mood",""),
                timestamp = o.optLong("timestamp", System.currentTimeMillis())
            )
        }
    }
}
